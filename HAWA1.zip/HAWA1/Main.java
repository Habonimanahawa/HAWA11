//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        //Question 1
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Yellow");

        System.out.println("Colors in the list: " + colors);

        //Question 2
        colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        for (String color : colors)

            System.out.println(color);

        //QUESTION3
        colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");

        colors.add(0, "Purple");

        System.out.println("After putting element at the first position: " + colors);

        //question4

        colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");

        String element = colors.get(1);
        System.out.println("Element at index 1: " + element);


        //Question 5

        colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");

        colors.set(1, "Yellow");

        System.out.println("Updated list: " + colors);

        //QUESTION6

        colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Yellow");

        colors.remove(2);

        System.out.println("After removing the third element: " + colors);

        //QUESTION 7

        colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");

        if (colors.contains("Blue")) {
            System.out.println("The list contains Blue.");
        } else {
            System.out.println("The list does not contain Blue.");
        }


        //question 8

        colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");

        Collections.sort(colors);

        System.out.println("Sorted list: " + colors);

        // QUESTION 9

Q21

    }
}







